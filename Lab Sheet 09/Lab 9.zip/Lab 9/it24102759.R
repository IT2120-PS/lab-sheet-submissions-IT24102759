getwd()
setwd("C:\\Users\\USER\\Desktop\\New folder")

#Exercise
#1
#i
y <- rnorm(25, mean=45, sd = 2)

##ii
t.test(y, mu=46, alternative= "less")

