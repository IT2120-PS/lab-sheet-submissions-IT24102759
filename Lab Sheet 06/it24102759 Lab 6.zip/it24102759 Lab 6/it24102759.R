setwd("C:\\Users\\USER\\OneDrive\\Desktop\\it24102759 Lab 6")

#Question 01
#Part 01
#Random variable X has binomial distribution with n = 50 and p = 0.85

#Part 02
#Probability of getting an exact value can be calculate using this command
pbinom(47,50,0.85)

#Question 02
#Part 01
#X = number of calls received per hour.

#Part 02
#Poisson Distribution
#Random variable X has poisson distribution with lambda = 12

#Part 03
#P(X = 15)
dpois(15,12)